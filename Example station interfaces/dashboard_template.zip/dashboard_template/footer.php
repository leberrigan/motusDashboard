
					<script src="<?php bloginfo('template_url'); ?>/mainInterface_svgMap.js"></script>
				</body>
			</html>
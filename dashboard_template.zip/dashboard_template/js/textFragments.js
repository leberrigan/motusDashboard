var textFragments = {
  explore_tab_projects_table_header_tagprojs: {
    stations: "Projects with tag detections",
    animals: "Projects with tag deployments",
    species: "Projects with tag deployments",
    regions: "Projects with tag deployments",
    projects: "Projects with tag deployments"
  },
  explore_tab_projects_table_header_recvprojs: {
    stations: "Projects with stations",
    animals: "Projects with tag deployments",
    species: "Projects with tag deployments",
    regions: "Projects with stations",
    projects: "Projects with stations"
  }
}

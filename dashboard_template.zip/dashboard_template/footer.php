
			<div class='footer'>

				<div>The Motus Wildlife Tracking System is a program by </div>
				<img src='images/birds-canada-logo-invert.png' alt="Visit Birds Canada" class='birds-canada-logo tips' />

			</div>
			<!-- Load Facebook SDK for JavaScript -->
				<div id="fb-root"></div>
				<script>(function(d, s, id) {
				var js, fjs = d.getElementsByTagName(s)[0];
				if (d.getElementById(id)) return;
				js = d.createElement(s); js.id = id;
				js.src = "https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v3.0";
				fjs.parentNode.insertBefore(js, fjs);
				}(document, 'script', 'facebook-jssdk'));</script>
			<!-- End your code here -->
		</body>
	</html>
